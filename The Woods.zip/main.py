
def the_woods_intro():
    
    print ("You wake up and you do not remember anything.")
    print ("You sit up and find yourself in the woods at dusk.")
    print ("You look around and there is a neglected barn to your left.")
    print ("To the right is a narrow bridge spanning a small stream.")
    print ("There is a path on the other side of the bridge. Do you go left toward the barn (1) or right toward the bridge (2)? ")

    choice = input("Type 1 for left or 2 for right:")

    if choice == "1":
        print ('\n' * 5)
        print ("======= You chose left: to the barn =======")
        print ("As you get closer to the barn you notice the door is open.")
        print ("It looks dark in the barn and you're scared.")
        print ("You don't know where you are, so you go in to see if you can find clues.")
        print ("It's really dark and you can't see anything.")
        print ("While you're waiting for your eyes to adjust to the darkness you hear footsteps.")
        print ("You strain your eyes and see a murderous clown approaching you.")
        print ("This is really happening!")
        print ("You run out the door.")
        print ("From your new vantage point you can see the bridge in the distance to your left.")
        print ("To the right is an empty field with a paved road on the other side of it.")
        
        left_to_barn()
        

        


   
    elif choice == "2":
        
        print ('\n' * 5)
        print ("====== You chose right: to the bridge ========")
        print ("You cross the bridge and start along a path winding through the woods.")
        print ("You walk along the path for 15 minutes.")
        print ("You hear traffic ahead.")
        print ("The path brings you to a road with a gas station on the other side.")
        print ("You go into the gas station and call someone to come pick you up.")
        print ("While you wait, you wonder how you got into the woods.")
        
        wait_or_walk()
        
        
    else:
                            print ("Invalid action.")
                            print ("Type 1 for left or 2 for right:")
                            the_woods_intro()


def left_to_barn():
    print ("You have to make a decision quickly. The clown is closing in on you!")
    print ("Do you run for the bridge (3) or for the road (4)?")
    choice = input ("Type 3 for the bridge or 4 for the road:")
    if choice == "3":
                            print ('\n' * 5)
                            print ("======= You chose the bridge =======")
                            print ("You run toward the bridge as fast as you can.")
                            print ("You run across the bridge and you hear a crashing sound behind you.")
                            print ("You look over your shoulder as you continue to run and see that the bridge has collapsed and the clown is trapped under it!")
                            print ("You don't slow down, this could be your only chance.")
                            print ("You hear traffic ahead.")
                            print ("The path brings you to a road with a gas station on the other side.")
                            print ("You go into the gas station and call someone to come pick you up.")
                            print ("While you wait, you wonder how you got into the woods.")
                            print ("Then you see the clown emerging from the woods!")
                            print ("You start running.")
                            print ("You don't warn anyone because, let's face it, your chances of survival are better this way.")
                            print ("You look over your shoulder as you run.")
                            print ("You're almost out of sight of the gas station, but you can see that the clown is dragging someone into the woods.")
                            print ("You feel bad, but mostly you're relieved that it's not you.")
                            print ("You see your friend's car approaching you!")
                            print ("Finally, you're headed home!")
                            print ('\n' * 2)
                            print ("====== Play Again? ======")
                            print ("WANT TO SEE WHAT ELSE MIGHT HAVE HAPPENED?")
                            print ("PLAY AGAIN AND FIND OUT!!")
                            the_woods_intro()
     
    elif choice == "4":

                            print ('\n' * 5)
                            print ("====== You chose the road ======")
                            print ("You run across the field as fast as you can.")
                            print ("It's unbelievable how fast this clown is running in his floppy shoes.")
                            print ("You reach the road and the clown is still close behind you.")
                            print ("Should you run to the left or right down the road?")
                            print ("Then you hear a train whistle.")
                            print ("You see the train tracks straight ahead with the train getting closer.")
                            print ("This is your only chance.")
                            print ("You run for the tracks as fast as you can.")
                            print ("You barely make it to the other side before the train comes barrelling through.")
                            print ("The clown is stuck on the other side of the tracks!")
                            print ("You still need to get away, so you look around.")
                            print ("You look down the slope and see a convenience store.")
                            print ("You run to the convenience store and call a friend to come pick you up.")
                            print ("You remain inside while you wait for your ride.")
                            print ("You shop for a few toiletries while you wait.")
                            print ("Your friend comes and the two of you pick up a pizza and then head over to your house to watch The Walking Dead.")
                            print ('\n' * 2)
                            print ("======= Play Again? ======")
                            print ("WANT TO SEE WHAT ELSE MIGHT HAVE HAPPENED?")
                            print ("PLAY AGAIN AND FIND OUT!!")
                            the_woods_intro()
    else:
                            print ("Invalid action.")
                            print ("Choose 3 for bridge or 4 for road:")
                            left_to_barn()
                
                
            

def wait_or_walk():
    print ("Your friend is taking a while to come get you.")
    print ("Should you keep waiting (5) or start walking home (6)?")
    choice = input ("Type 5 to keep waiting or 6 to start walking.")

    if choice == "5":
        print ('\n' * 5)
        print ("====== You chose to keep waiting =======")
        print ("You wait for another 20 minutes and your ride finally shows up.")
        print ("You sit in the passenger seat quietly because you're too confused to explain what happened.")
        print ("You look out the window and see a murderous clown standing at the edge of the woods.")
        print ("You look ahead and don't say anything.")
        print ("You're pretty sure that clown would have killed you if you'd stayed in the woods any longer.")
        print ("You get home and quickly lock all of your doors.")
        print ("That was a weird night.")
        print ("You turn on the TV and watch The Walking Dead to relax.")
        print ('\n' * 2)
        print ("======= Play Again? =======")
        print ("WANT TO SEE WHAT ELSE MIGHT HAVE HAPPENED?")
        print ("PLAY AGAIN AND FIND OUT!!")
        the_woods_intro()

    elif choice =="6":
        print ('\n' * 5)
        print ("====== You chose to start walking =======")
        print ("You start walking in the direction of your house. You'll probably see your friend headed toward you any minute now.")
        print ("It's getting pretty dark and you start to second guess your decision to walk.")
        print ("You're out of sight of the gas station now and it's creepy dark.")
        print ("And then it happens.")
        print ("A murderous clown emerges from the edge of the woods directly in front of you!")
        print ("You run to the other side of the road.")
        print ("You keep running as fast as you can.")
        print ("You see headlights from a car ahead!")
        print ("The car gets closer and you see that it's your friend!")
        print ("Your friend slams on the brakes and you jump in.")
        print ("Your friend sees the clown and totally freaks.")
        print ("You reach over and and put your foot on the gas pedal. You floor it.")
        print ("You run over the clown.")
        print ("Three hours later you finally get home. It took longer than you thought it would for you and your friend to bury the clown in the woods.")
        print ("You lock all your doors and settle down to watch some TV.")
        print ("While you channel surf you think about the strange night you had.")
        print ("Maybe you can adapt it into a short story or a video game.")
        print ('\n' * 2)
        print ("====== Play Again? ======")
        print ("WANT TO SEE WHAT ELSE MIGHT HAVE HAPPENED?")
        print ("PLAY AGAIN AND FIND OUT!!")
        the_woods_intro()    
               

    

    else:
            print ("Invalid action.")
            print ("Type 5 for wait or 6 for walk:")
            wait_or_walk()



the_woods_intro()


